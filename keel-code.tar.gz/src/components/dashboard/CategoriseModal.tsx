'use client'

import { useState } from 'react'
import { doc, updateDoc, setDoc, Timestamp } from 'firebase/firestore'
import { db } from '@/lib/firebase'
import { useCategories } from '@/lib/hooks'
import { useAuth } from '@/contexts/AuthContext'
import type { KeelItem } from '@/lib/types'

interface CategoriseModalProps {
  items:   KeelItem[]
  onClose: () => void
}

export function CategoriseModal({ items, onClose }: CategoriseModalProps) {
  const { user }        = useAuth()
  const { categories }  = useCategories()
  const [saving, setSaving]         = useState(false)
  const [done, setDone]             = useState<string[]>([])
  const [creating, setCreating]     = useState(false)
  const [newName, setNewName]       = useState('')
  const [newDesc, setNewDesc]       = useState('')
  const [creatingError, setCreatingError] = useState('')

  const remaining = items.filter(i => !done.includes(i.itemId))
  const item      = remaining[0] ?? null
  const progress  = Math.round(((items.length - remaining.length) / items.length) * 100)

  const assign = async (categoryId: string, categoryName: string) => {
    if (!user || !item || saving) return
    setSaving(true)
    try {
      await updateDoc(doc(db, `users/${user.uid}/items`, item.itemId), {
        categoryId, categoryName, updatedAt: Timestamp.now(),
      })
      setDone(d => [...d, item.itemId])
    } catch (e) { console.error(e) }
    finally { setSaving(false) }
  }

  const createAndAssign = async () => {
    if (!user || !item || !newName.trim() || saving) return
    setSaving(true)
    setCreatingError('')
    try {
      const catId   = `cat_${Date.now()}`
      const now     = Timestamp.now()
      await setDoc(doc(db, `users/${user.uid}/categories`, catId), {
        categoryId: catId, name: newName.trim(),
        description: newDesc.trim(), icon: 'tag',
        order: categories.length + 1, archived: false,
        archivedAt: null, itemCount: 0, parentId: null,
        createdAt: now, updatedAt: now,
      })
      await assign(catId, newName.trim())
      setCreating(false)
      setNewName('')
      setNewDesc('')
    } catch (e) {
      console.error(e)
      setCreatingError('Failed to create category — please try again')
    } finally { setSaving(false) }
  }

  const skip = () => {
    if (!item) return
    setDone(d => [...d, item.itemId])
  }

  return (
    <div
      style={{ position: 'fixed', inset: 0, zIndex: 500, background: 'var(--color-overlay)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}
      onClick={onClose}
    >
      <div
        style={{ width: '100%', maxWidth: 520, background: 'var(--color-surface)', borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)', overflow: 'hidden', border: '1px solid var(--color-border)' }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--color-border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--color-text-primary)' }}>
              {creating ? 'Create new category' : 'Categorise items'}
            </div>
            <div style={{ fontFamily: 'var(--font-dm-mono)', fontSize: 11, color: 'var(--color-text-muted)', marginTop: 2 }}>
              {creating ? 'Name your category and optionally describe it' : `${remaining.length} remaining of ${items.length}`}
            </div>
          </div>
          <button onClick={creating ? () => setCreating(false) : onClose} style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--color-text-muted)', fontSize: 20, lineHeight: 1 }}>
            {creating ? '←' : '×'}
          </button>
        </div>

        {/* Progress bar */}
        {!creating && (
          <div style={{ height: 3, background: 'var(--color-border)' }}>
            <div style={{ height: '100%', width: `${progress}%`, background: 'var(--color-accent)', transition: 'width 0.3s ease' }} />
          </div>
        )}

        {/* Create new category form */}
        {creating ? (
          <div style={{ padding: '16px 20px 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--color-text-primary)', display: 'block', marginBottom: 6 }}>
                Category name
              </label>
              <input
                autoFocus
                value={newName}
                onChange={e => setNewName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && createAndAssign()}
                placeholder="e.g. Drama & Social, Job Search, Side Projects"
                style={{ width: '100%', background: 'var(--color-surface-recessed)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: '9px 12px', fontSize: 13, color: 'var(--color-text-primary)', fontFamily: 'var(--font-dm-sans)', outline: 'none', boxSizing: 'border-box' }}
              />
            </div>

            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--color-text-primary)', display: 'block', marginBottom: 4 }}>
                Description <span style={{ fontWeight: 400, color: 'var(--color-text-muted)' }}>(optional but recommended)</span>
              </label>
              <div style={{ background: 'var(--color-accent-sub)', border: '1px solid var(--color-accent)', borderRadius: 'var(--radius-md)', padding: '10px 12px', marginBottom: 8, fontSize: 11, color: 'var(--color-accent)', lineHeight: 1.6 }}>
                <strong>Tip:</strong> A good description helps Keel automatically place future emails here — no manual categorising needed. Be specific about what belongs: who sends these emails, what they're about, and any key terms.
                <br /><br />
                <strong>Example:</strong> <em>"Emails about our rental property in Bath — from letting agents (Savills, Fox &amp; Sons), tenants, maintenance contractors, and the local council. Includes rent payments, repair requests, and compliance certificates."</em>
              </div>
              <textarea
                value={newDesc}
                onChange={e => setNewDesc(e.target.value)}
                placeholder="Describe what kinds of emails belong here..."
                rows={3}
                style={{ width: '100%', background: 'var(--color-surface-recessed)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: '9px 12px', fontSize: 12, color: 'var(--color-text-primary)', fontFamily: 'var(--font-dm-sans)', outline: 'none', resize: 'vertical', lineHeight: 1.5, boxSizing: 'border-box' }}
              />
            </div>

            {creatingError && (
              <div style={{ fontSize: 12, color: 'var(--color-status-urgent)' }}>{creatingError}</div>
            )}

            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={() => setCreating(false)} style={{ flex: 1, padding: '9px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', background: 'transparent', cursor: 'pointer', fontSize: 13, color: 'var(--color-text-muted)', fontFamily: 'var(--font-dm-sans)' }}>
                Cancel
              </button>
              <button
                onClick={createAndAssign}
                disabled={!newName.trim() || saving}
                style={{ flex: 2, padding: '9px', borderRadius: 'var(--radius-md)', border: 'none', background: 'var(--color-accent)', cursor: !newName.trim() || saving ? 'not-allowed' : 'pointer', fontSize: 13, fontWeight: 600, color: 'white', fontFamily: 'var(--font-dm-sans)', opacity: !newName.trim() || saving ? 0.6 : 1 }}
              >
                {saving ? 'Creating...' : 'Create & assign →'}
              </button>
            </div>
          </div>

        ) : !item ? (
          /* All done */
          <div style={{ padding: '40px 20px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--color-status-positive)', opacity: 0.7 }}>
              <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
              <polyline points="22 4 12 14.01 9 11.01"/>
            </svg>
            <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--color-text-primary)' }}>All categorised!</div>
            <div style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{items.length} item{items.length !== 1 ? 's' : ''} assigned.</div>
            <button onClick={onClose} style={{ marginTop: 8, background: 'var(--color-accent)', color: 'white', border: 'none', borderRadius: 'var(--radius-md)', padding: '8px 20px', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-dm-sans)' }}>
              Done
            </button>
          </div>

        ) : (
          <>
            {/* Item preview */}
            <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--color-border)', background: 'var(--color-surface-recessed)' }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--color-text-primary)', marginBottom: 4 }}>{item.aiTitle || item.subject}</div>
              <div style={{ fontSize: 12, color: 'var(--color-text-muted)', marginBottom: 6 }}>
                {item.senderName} · {item.receivedAt.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
              </div>
              {item.aiSummary && (
                <div style={{ fontSize: 12, color: 'var(--color-text-secondary)', lineHeight: 1.5 }}>{item.aiSummary}</div>
              )}
            </div>

            {/* Category picker */}
            <div style={{ padding: '12px 20px 16px' }}>
              <div style={{ fontFamily: 'var(--font-dm-mono)', fontSize: 10, color: 'var(--color-text-muted)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10 }}>
                Assign to category
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, maxHeight: 240, overflowY: 'auto' }}>
                {categories.map(cat => (
                  <button
                    key={cat.categoryId}
                    onClick={() => assign(cat.categoryId, cat.name)}
                    disabled={saving}
                    style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', background: 'var(--color-surface)', cursor: saving ? 'not-allowed' : 'pointer', fontSize: 13, fontWeight: 500, color: 'var(--color-text-primary)', fontFamily: 'var(--font-dm-sans)', textAlign: 'left', transition: 'all 0.1s', opacity: saving ? 0.6 : 1 }}
                    onMouseOver={e => { e.currentTarget.style.borderColor = 'var(--color-accent)'; e.currentTarget.style.color = 'var(--color-accent)' }}
                    onMouseOut={e => { e.currentTarget.style.borderColor = 'var(--color-border)'; e.currentTarget.style.color = 'var(--color-text-primary)' }}
                  >
                    {cat.name}
                  </button>
                ))}

                {/* Create new */}
                <button
                  onClick={() => setCreating(true)}
                  disabled={saving}
                  style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 12px', borderRadius: 'var(--radius-md)', border: '1.5px dashed var(--color-accent)', background: 'var(--color-accent-sub)', cursor: 'pointer', fontSize: 13, fontWeight: 600, color: 'var(--color-accent)', fontFamily: 'var(--font-dm-sans)', textAlign: 'left' }}
                >
                  + New category
                </button>
              </div>

              <button
                onClick={skip}
                style={{ marginTop: 10, width: '100%', padding: '7px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', background: 'transparent', cursor: 'pointer', fontSize: 12, color: 'var(--color-text-muted)', fontFamily: 'var(--font-dm-sans)' }}
              >
                Skip this item
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
